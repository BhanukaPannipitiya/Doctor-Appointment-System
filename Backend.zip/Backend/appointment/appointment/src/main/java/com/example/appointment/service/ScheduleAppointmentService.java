package com.example.appointment.service;

import com.example.appointment.data.ScheduleAppointment;
import com.example.appointment.data.ScheduleAppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleAppointmentService {
    @Autowired
    private ScheduleAppointmentRepository scheduleAppointmentRepository;

    public List<ScheduleAppointment> getAllScheduleAppointments()
    {
        List<ScheduleAppointment> scheduleAppointments=scheduleAppointmentRepository.findAll();
        return scheduleAppointments;
    }
    public ScheduleAppointment getScheduleAppointmentsByID(int id)
    {
        Optional<ScheduleAppointment> scheduleAppointment=scheduleAppointmentRepository.findById(id);
        return scheduleAppointment.get();
    }
    public ScheduleAppointment createScheduleAppointment(ScheduleAppointment scheduleAppointment)
    {
        return scheduleAppointmentRepository.save(scheduleAppointment);
    }
}
