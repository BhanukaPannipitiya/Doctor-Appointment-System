package com.example.appointment.controller;

import com.example.appointment.data.Appointment;
import com.example.appointment.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
public class AppointmentController {
    @Autowired
    private AppointmentService appointmentService;

    @GetMapping(path="/appointments")
    public List<Appointment>getAllAppointments()
    {
        return appointmentService.getAllAppointments();
    }


    @PostMapping(path="/appointments")
    public Appointment createAppointment(@RequestBody Appointment appointment)
    {
        return appointmentService.createAppointment(appointment);
    }
    @DeleteMapping(path="/appointments/{id}")
    public void deleteAppointmentById(@PathVariable int id)
    {
        appointmentService.deleteAppointmentById(id);
    }
}
