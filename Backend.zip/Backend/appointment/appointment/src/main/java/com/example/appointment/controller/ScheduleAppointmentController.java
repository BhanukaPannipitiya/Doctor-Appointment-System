package com.example.appointment.controller;

import com.example.appointment.data.ScheduleAppointment;
import com.example.appointment.service.ScheduleAppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@CrossOrigin("*")
@RestController
public class ScheduleAppointmentController {
    @Autowired
    private ScheduleAppointmentService scheduleAppointmentService;

    @GetMapping(path="/scheduleappointments")
    public List<ScheduleAppointment>getAllScheduleAppointments()
    {
        return scheduleAppointmentService.getAllScheduleAppointments();
    }
    @GetMapping(path = "/scheduleappointments/{id}")
    public  ScheduleAppointment getScheduleAppointmentById(@PathVariable int id)
    {
        return scheduleAppointmentService.getScheduleAppointmentsByID(id);
    }
    @PostMapping(path="/scheduleappointments")
    public ScheduleAppointment createScheduleAppointment(@RequestBody ScheduleAppointment scheduleAppointment)
    {
        return scheduleAppointmentService.createScheduleAppointment(scheduleAppointment);
    }
}
