package com.example.appointment.service;

import com.example.appointment.data.Appointment;
import com.example.appointment.data.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {
    @Autowired
    private AppointmentRepository appointmentRepository;

    public List<Appointment> getAllAppointments()
    {
        List<Appointment> appointment =appointmentRepository.findAll();
        return appointment;
    }
    public Appointment createAppointment(Appointment appointment)
    {
        return appointmentRepository.save(appointment);
    }
    public void deleteAppointmentById(int id)
    {
        appointmentRepository.deleteById(id);
    }

}
