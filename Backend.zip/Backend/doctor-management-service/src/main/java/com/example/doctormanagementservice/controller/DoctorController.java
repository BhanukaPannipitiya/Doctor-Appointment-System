package com.example.doctormanagementservice.controller;


import com.example.doctormanagementservice.data.Doctor;
import com.example.doctormanagementservice.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;


	@CrossOrigin("*")
	@PostMapping(path = "doctors")
	public Doctor createDoctor(@RequestBody Doctor doctor)
	{
		return doctorService.createDoctor(doctor);
	}

	@GetMapping(path = "doctors")
	public List<Doctor> getDoctor()
	{
		return doctorService.getDoctor();
	}

	@GetMapping(path = "doctors/{id}")
	public Doctor getDoctorById(@PathVariable int id)
	{
		return doctorService.getDoctorById(id);
	}

	@PutMapping(path = "doctors")
	public Doctor updateDoctor(@RequestBody Doctor doctor)
	{
		return doctorService.updateDoctor(doctor);
	}



}
