package com.example.doctormanagementservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorManagementServiceApplication.class, args);
	}

}
