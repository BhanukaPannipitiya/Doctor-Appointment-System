package com.example.doctormanagementservice.service;


import com.example.doctormanagementservice.data.Doctor;
import com.example.doctormanagementservice.data.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;

	public Doctor createDoctor(Doctor doc)
	{
		return doctorRepository.save(doc);
	}

	public List<Doctor> getDoctor()
	{
		 List<Doctor> doctor = doctorRepository.findAll();
		return doctor;
	}
	public Doctor getDoctorById(int id)
	{
		Optional<Doctor> doc = doctorRepository.findById(id);
		return doc.get();
	}
	public Doctor updateDoctor(Doctor doc)
	{
		return doctorRepository.save(doc);
	}


}
