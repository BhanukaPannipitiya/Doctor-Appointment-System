package com.example.doctormanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
