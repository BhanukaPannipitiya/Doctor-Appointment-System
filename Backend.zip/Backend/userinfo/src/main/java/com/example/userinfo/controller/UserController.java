package com.example.userinfo.controller;

import com.example.userinfo.data.User;
import com.example.userinfo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin("*")
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping(path="/users")
    public List<User>getAllUsers()
    {
        return userService.getAllUsers();
    }
    @PostMapping(path="/users")
    public User createUser(@RequestBody User user)
    {
        return userService.createUser(user);
    }
    @GetMapping(path="/users/{id}")
    public User getUserById(@PathVariable int id)
    {
        return userService.getUserById(id);
    }
}
