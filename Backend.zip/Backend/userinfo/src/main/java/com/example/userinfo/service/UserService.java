package com.example.userinfo.service;

import com.example.userinfo.data.User;
import com.example.userinfo.data.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository ur;

    public List<User> getAllUsers()
    {
        List<User> user = ur.findAll();
        return user;
    }
    public User getUserById(int id)
    {
        Optional<User> user = ur.findById(id);
        return user.get();
    }
    public User createUser(User user)
    {
        return ur.save(user);
    }
    public User updateUser(User user)
    {
        return ur.save(user);
    }
}
